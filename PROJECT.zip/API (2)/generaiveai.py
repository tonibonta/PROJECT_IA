import google.generativeai as genai
with open("tmp.txt", 'r') as file:
        chat = file.read()
with open("tmp.txt", 'a') as file:
    
    while (True):
        s=input("inserisci input: ")
        chat+=f"{s}\n"
        file.write(f"{s}\n")
        genai.configure(api_key="AIzaSyAvPNGrQQ__Xn-PVLJNfIj9wp8qsew97vc")
        model = genai.GenerativeModel("gemini-1.5-flash")
        response = model.generate_content(chat)
        print(response.text)